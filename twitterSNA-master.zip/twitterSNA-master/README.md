# twitterSNA
A tool to find a twitter social network from a username

## Getting Started

Just run python twitterSNA from the commandline and a map will be saved in /maps

### Prerequisites

* folium
* tweepy
* geopy

### Example

python twitterSNA.py username

